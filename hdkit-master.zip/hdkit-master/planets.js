var Planets = {
	all: [Sun, Earth, NorthNode, SouthNode, Moon, Mercury, Venus, Mars, Jupiter, Saturn, Uranus, Neptune, Pluto, Chiron]
}